#include "ResourcesManager.h"

// TODO: Update for another machine
std::string ResourcesManager::rootPath = R"(C:\Users\vthan\Documents\Advanced Programming\OnlineBowling\Resources)";